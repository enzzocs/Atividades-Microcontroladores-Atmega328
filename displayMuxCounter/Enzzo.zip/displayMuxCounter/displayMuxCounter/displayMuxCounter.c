/*
 * buttonMuxDisplay.c
 *
 * Created: 28/08/2017 10:40:52
 *  Author: Schwarz
 */

#define F_CPU	16000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>

#define setBit(var, bit)		(var = var | (1<<bit))
#define clrBit(var, bit)		(var = var & ~(1<<bit))
#define invertBit(var, bit)		(var = var ^ (1<<bit))

#define testBitClr(var, bit)    !((var & (1 << bit)))
#define testBitSet(var, bit)	(var & (1 << bit))

volatile unsigned int number = 1802;

volatile unsigned int tst3 = 0;
volatile unsigned int tst2 = 0;
volatile unsigned int tst1 = 0;
volatile unsigned int tst0 = 0;

unsigned char decode(unsigned int cont);

int main(void)
{
	unsigned char segments[4];
	unsigned char i = 0;

	// Display configuration
	DDRD = 0xFF;
	DDRC = 0x0F;
	PORTC = 0x0F;

	// PCINT configuration
	setBit(PORTB, PB0);
	setBit(PORTB, PB1);
	setBit(PORTB, PB2);
	setBit(PORTB, PB3);
	setBit(PCICR, PCIE0);
	setBit(PCMSK0, PCINT0);
	setBit(PCMSK0, PCINT1);
	setBit(PCMSK0, PCINT2);
	setBit(PCMSK0, PCINT3);

	// Enables global interrupts
	sei();

	while(1) {
		segments[0] = decode(number % 10);
		segments[1] = decode((number / 10) % 10);
		segments[2] = decode((number / 100) % 10);
		segments[3] = decode((number / 1000) % 10);

		for(i = 0; i < 4; i++) {
			PORTC = 0x0F;
			PORTD = segments[i];
			clrBit(PORTC, (PC0 + i));
			_delay_ms(5);
		}
	}
	return 0;
}

ISR(PCINT0_vect)
{
	if(testBitSet(PINB, PB3) && (tst3 == 1)) {
		number++;
		tst3 = 0;
	}
	if(testBitClr(PINB, PB3)) {
		tst3 = 1;
	}
	if(testBitSet(PINB, PB2) && (tst2 == 1)) {
		number += 10;
		tst2 = 0;
	}
	if(testBitClr(PINB, PB2)) {
		tst2 = 1;
	}
	if(testBitSet(PINB, PB1) && (tst1 == 1)) {
		number += 100;
		tst1 = 0;
	}
	if(testBitClr(PINB, PB1)) {
		tst1 = 1;
	}
	if(testBitSet(PINB, PB0) && (tst0 == 1)) {
		number += 1000;
		tst0 = 0;
	}
	if(testBitClr(PINB, PB0)) {
		tst0 = 1;
	}
	////////////////////////////////////////////////////////////////////////////////
	// Realce de c�digo � estouro c�clico do contador //////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
	if(number > 10000) {
		number -= 10000;
	}
	////////////////////////////////////////////////////////////////////////////////
	// Fim do Realce ///////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////
}

unsigned char decode(unsigned int cont)
{
	switch(cont) {
	case 0:
		return 0xC0;
	case 1:
		return 0xF9;
	case 2:
		return 0XA4;
	case 3:
		return 0XB0;
	case 4:
		return 0X99;
	case 5:
		return 0X92;
	case 6:
		return 0X83;
	case 7:
		return 0XF8;
	case 8:
		return 0X80;
	case 9:
		return 0X98;
	default:
		return 0;

	}
}